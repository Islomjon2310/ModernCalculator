# Modern Calculator Android

Android Studio loyiha. Ilova internet talab qilmaydi va kalkulyator interfeysi ichki HTML fayldan ishlaydi.

## APK yig‘ish (eng oson yo‘l: GitHub Actions)
1. Ushbu ZIP faylni oching.
2. Ichidagi fayllarni yangi GitHub repository'ga yuklang (ZIPni repository sahifasida to‘g‘ridan-to‘g‘ri yuklash emas, avval extract qilish kerak).
3. GitHub → Actions bo‘limiga kiring.
4. "Build Android APK" workflow'ini tanlab, "Run workflow" bosing.
5. Tugagach, workflow sahifasining Artifacts qismidan `ModernCalculator-APK` ni yuklab oling.
6. ZIP ichidagi `app-debug.apk` faylini Samsung telefoningizda ochib o‘rnating. Android noma'lum ilova o‘rnatishga ruxsat so‘rashi mumkin.

APK hozircha debug imzo bilan yig‘iladi; shaxsiy foydalanish va sinov uchun mos. Play Store uchun alohida release signing kerak.
